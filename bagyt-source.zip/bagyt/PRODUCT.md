# Product
<!-- impeccable:product-schema 1 -->
## Platform
web
## Stack
Implementation delegated by user: Vite, vanilla JS, Supabase Auth/Postgres, GitHub Pages.
## Product Purpose
Kazakh dynamic QR management: immutable public UUID, editable destination, authenticated owner dashboard. All UI copy in Kazakh.
## Capabilities and Constraints
Create, edit, pause, delete, search, PNG/SVG download; anonymous resolve via narrow RPC; no privileged frontend secrets. Network availability depends on providers. Production accounts and backend credentials not supplied.
## Accessibility & Inclusion
Responsive keyboard access, focus visibility, labels, reduced motion, semantic dialogs and live feedback.
## Open decisions
Бағыт is a proposed product name; demonstration data is explicitly illustrative.
