export function safeUrl(value) {
  const raw = String(value).trim();
  if (raw.length > 2048 || /[\s\u0000-\u001f\u007f]/.test(raw)) throw new Error('URL жарамсыз.');
  let url; try { url = new URL(raw); } catch { throw new Error('https:// деп басталатын толық сілтемені енгізіңіз.'); }
  if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || !url.hostname) throw new Error('Тек HTTP немесе HTTPS сілтемелеріне рұқсат етіледі.');
  return url.href;
}
export const validId = value => /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value || '');
export function publicUrl(id, base = window.location.href) { const url = new URL(base); url.search = ''; url.hash = ''; url.searchParams.set('id', id); return url.href; }
export function escapeHtml(value) { return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
export function filterLinks(rows, query, status) { return rows.filter(r => (status === 'all' || (status === 'active' ? r.is_active : !r.is_active)) && `${r.title} ${r.destination}`.toLocaleLowerCase('kk').includes(query.toLocaleLowerCase('kk'))); }
