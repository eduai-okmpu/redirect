// Public browser configuration. Never put secret/service_role keys here.
window.BAGYT_CONFIG = {
  supabaseUrl: 'https://gbrgrqqyqekmyuwdlylg.supabase.co',
  supabaseKey: 'sb_publishable_TL8hNZRPml1yoHAWzWgyqQ_JFXsDU1K'
};
