-- Apply once using Supabase SQL editor or supabase db push.
begin;
create table public.links (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
 title text not null check (char_length(btrim(title)) between 1 and 100),
 destination text not null check (char_length(destination) <= 2048 and destination ~* '^https?://[^/@[:space:]]+([/?#][^[:space:]]*)?$' and destination !~ '[[:cntrl:]]'),
 is_active boolean not null default true,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create index links_owner_created on public.links(owner_id,created_at desc);
alter table public.links enable row level security;
revoke all on public.links from anon, authenticated;
grant select, delete on public.links to authenticated;
grant insert (owner_id,title,destination,is_active) on public.links to authenticated;
grant update (title,destination,is_active) on public.links to authenticated;
create policy owner_select on public.links for select to authenticated using ((select auth.uid()) = owner_id);
create policy owner_insert on public.links for insert to authenticated with check ((select auth.uid()) = owner_id);
create policy owner_update on public.links for update to authenticated using ((select auth.uid()) = owner_id) with check ((select auth.uid()) = owner_id);
create policy owner_delete on public.links for delete to authenticated using ((select auth.uid()) = owner_id);
create function public.protect_link_identity() returns trigger language plpgsql set search_path = '' as $$
begin
 if new.id is distinct from old.id or new.owner_id is distinct from old.owner_id or new.created_at is distinct from old.created_at then
  raise exception 'Immutable link identity';
 end if;
 new.updated_at = now();
 return new;
end;
$$;
create trigger protect_link_identity before update on public.links for each row execute function public.protect_link_identity();
revoke all on function public.protect_link_identity() from public, anon, authenticated;
-- Deliberately returns one destination only; never expose owner/email or permit anonymous listing.
create function public.resolve_link(public_id uuid) returns text language sql stable security definer set search_path = '' as $$
 select destination from public.links where id = public_id and is_active = true;
$$;
revoke all on function public.resolve_link(uuid) from public, anon, authenticated;
grant execute on function public.resolve_link(uuid) to anon, authenticated;
commit;
