import {test} from 'node:test';
import assert from 'node:assert/strict';
import {safeUrl,validId,publicUrl,escapeHtml,filterLinks} from '../src/core.js';
test('URLs: permit web addresses, reject script, credentials, malformed and control characters',()=>{
 assert.equal(safeUrl('https://example.com/a?b=1'),'https://example.com/a?b=1');
 for(const value of ['javascript:alert(1)','data:text/html,test','ftp://example.com','https://user:pw@example.com','https://example.com\n.test','example.com','https://','//example.com']) assert.throws(()=>safeUrl(value));
});
test('immutable public UUID validation and Pages subpath preservation',()=>{
 const id='d5035381-afc4-41b4-a828-ea33282c1250'; assert.ok(validId(id));assert.ok(!validId('../x'));assert.ok(!validId(''));
 assert.equal(publicUrl(id,'https://name.github.io/bagyt/?old=1#session'),`https://name.github.io/bagyt/?id=${id}`);
});
test('untrusted titles cannot inject markup',()=>assert.equal(escapeHtml('<img src=x onerror="alert(1)">'),'&lt;img src=x onerror=&quot;alert(1)&quot;&gt;'));
test('search and status filters compose',()=>{const rows=[{title:'Мәзір',destination:'https://a.kz',is_active:true},{title:'Сайт',destination:'https://b.kz',is_active:false}];assert.equal(filterLinks(rows,'МӘЗ','active').length,1);assert.equal(filterLinks(rows,'','paused').length,1);assert.equal(filterLinks(rows,'жоқ','all').length,0);});
